;; GNU Emacs major mode for editing SGML source
;; Copyright (C) 1988 Exoterica

(defvar sgml-mode-abbrev-table nil
  "Abbrev table used while in sgml mode.")

(defvar sgml-mode-map nil
     "Major mode keymap for sgml-mode buffers")
(if (not sgml-mode-map)
    (progn
      (setq sgml-mode-map (make-sparse-keymap))
      (define-key sgml-mode-map "\t"  'tab-to-tab-stop)
      (define-key sgml-mode-map "\es" 'center-line)
      (define-key sgml-mode-map "\e?" 'count-text-lines)
      (define-key sgml-mode-map "\en" 'forward-text-line)
      (define-key sgml-mode-map "\ep" 'backward-text-line)))

(defun sgml-mode ()
  "Major mode for editing text intended for sgml to format.
\\{sgml-mode-map}
Turning on Sgml mode runs text-mode-hook, then sgml-mode-hook."
  (interactive)
  (kill-all-local-variables)
  (use-local-map sgml-mode-map)
  (setq mode-name "Sgml")
  (setq major-mode 'sgml-mode)
  (set-syntax-table text-mode-syntax-table)
  (setq local-abbrev-table sgml-mode-abbrev-table)
  ;; now define a bunch of variables for use by commands in this mode
  (make-local-variable 'paragraph-start)
  (setq paragraph-start (concat "^<\\|" paragraph-start))
  (make-local-variable 'paragraph-separate)
  (setq paragraph-separate (concat "^<\\|" paragraph-separate))
  (run-hooks 'text-mode-hook 'sgml-mode-hook))

(defun count-text-lines (start end &optional print)
  "Count lines in region, except for sgml request lines.
All lines not starting with a period are counted up.
Interactively, print result in echo area.
Noninteractively, return number of non-request lines from START to END."
  (interactive "r\np")
  (if print
      (message "Region has %d text lines" (count-text-lines start end))
    (save-excursion
      (save-restriction
	(narrow-to-region start end)
	(goto-char (point-min))
	(- (buffer-size) (forward-text-line (buffer-size)))))))

(defun forward-text-line (&optional cnt)
  "Go forward one sgml text line, skipping lines of sgml requests.
An argument is a repeat count; if negative, move backward."
  (interactive "p")
  (if (not cnt) (setq cnt 1))
  (while (and (> cnt 0) (not (eobp)))
    (forward-line 1)
    (while (and (not (eobp)) (looking-at "<."))
      (forward-line 1))
    (setq cnt (- cnt 1)))
  (while (and (< cnt 0) (not (bobp)))
    (forward-line -1)
    (while (and (not (bobp))
		(looking-at "<."))
      (forward-line -1))
    (setq cnt (+ cnt 1)))
  cnt)

(defun backward-text-line (&optional cnt)
  "Go backward one sgml text line, skipping lines of sgml requests.
An argument is a repeat count; negative means move forward."
  (interactive "p")
  (forward-text-line (- cnt)))
