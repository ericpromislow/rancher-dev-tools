; emacs startup file

; I don't know why all this stuff is broken.
; (setenv "PATH" "...")
;
; fix: run this under csh -c ...

(setq default-directory "/Users/ericp/")

(setq-default indent-tabs-mode nil)

(defun tab4 ()
  "Change tab-spacing to 4."
  (interactive)
  (set-variable 'tab-width 4))

; Finally, commands to execute at startup
; First, load my modified gosmacs file

(load-file "/Users/ericp/emacs/gosmacs.el")
(load-file "/Users/ericp/emacs/go-mode.el")
(load-file "/Users/ericp/emacs/typescript-mode.el")
; needs a buncha things
; (load-file "/Users/ericp/emacs/vue-mode.el")

(setq load-path (cons "/Users/ericp/emacs" load-path))

(autoload 'cperl-mode "cperl-mode.el" t nil)
(autoload 'csharp-mode "csharp-mode.el" t nil)
; (autoload 'js2-mode "js2" nil t)
(set-gosmacs-bindings)

(set-variable 'scroll-step 1)
(set-variable 'tab-width 4)
(set-variable 'require-final-newline t)
(set-variable 'auto-save-interval 1600)
(set-variable 'line-move-visual nil)

(put 'narrow-to-region 'disabled nil)

(global-set-key "\e " 'set-mark-command)
(global-set-key "\e\C-z" 'zap-to-char)
(global-set-key "\C-x\C-n" 'gosmacs-next-window)
(global-set-key "\C-x\C-p" 'gosmacs-previous-window)
(global-set-key "\C-cn"	'narrow-to-region)	; esc-n too easy to hit.
; (global-set-key "\C-c\C-s"	'nonincremental-search-forward)
(global-set-key "\C-xw"	'widen)
(global-set-key "\C-cw"	'compare-windows) ; do this too often
(global-set-key "\C-c\C-w" 'compare-windows) ; either one
(global-set-key "\C-xt"	'text-mode)
(global-set-key "\eg" 'goto-line)
(global-set-key "\e\C-g" 'goto-char)
(global-set-key "\e\C-r" 'replace-regexp)
(global-set-key "\C-x\C-o" 'delete-blank-lines)
; (global-set-key "\C-xr" 'rmail)
(global-set-key "\C-xc" 'compare-windows)
(global-set-key "\C-xf" 'query-replace-regexp) ; set-fill-column is too dangerous
;;;; (global-set-key "\e\C-." 'find-tag)

;;;; (global-set-key "�" 'find-tag)

(global-set-key "\e\C-l" 'fill-paragraph)
(global-set-key "\e\C-y" 'auto-fill-mode)

; It toggles betwee Latin-1 and
;  octal notation for high-order characters (although you have to get the
; window to redraw after you do it).
(global-set-key "\C-x\C-u"	'standard-display-european)

; These keys are too dangerous in emacs 18.52
(global-unset-key "\C-x\C-u")
(global-unset-key "\C-x\C-l")

; This is now bound to \C-x\e\e
; (global-set-key "\C-x\ep" 'repeat-complex-command)
; things to do during transition to emacs 19.x:
(global-set-key "\e]" 'forward-paragraph)
(global-set-key "\e[" 'backward-paragraph)

; Klaus's sun-specific keys

; Talk to Klaus how to get these to work
; (global-set-key [find] 'isearch-forward)
; (global-set-key [S-find] 'isearch-backward)
; (global-set-key [M-find] 'tags-search)
; (global-set-key [SunCopy] 'kill-ring-save)
; (global-set-key [SunCut] 'kill-region)
; (global-set-key [SunPaste] 'yank)
; (global-set-key [M-SunPaste] 'yank-pop)
; (global-set-key [undo] 'undo)

; This key changes the thick NW arrow to a thin NE arrow,
; but does nothing else. No like.  This doesn't work.
(global-unset-key "\C-x\C-@")

;(remove-hook 'mail-mode-hook 'mail-hist-define-keys)
;(remove-hook 'vm-mail-mode-hook 'mail-hist-define-keys)

;;;; (setq search-highlight nil)

; Turn off auto-fill mode whenever text-mode is entered
; and turn off auto-saving for each buffer
(setq text-mode-hook
      '(lambda ()
	 (auto-fill-mode 1)
;	 (setq case-fold-search nil)
;;;;	 (auto-save-mode 0)
	 ))

; Turn off auto-fill and auto-save mode
(setq indented-text-mode-hook
      '(lambda ()
	 (auto-fill-mode 0)
;	 (setq case-fold-search nil)
	 (auto-save-mode 0)
	 ))

(setq cperl-mode-hook
      '(lambda ()
	 (progn
					; (font-lock-mode nil)
	   (set-variable 'tab-width 8)
	   (setq perl-indent-level 4)
	   (setq perl-continued-statement-offset 4)
	   (setq perl-continued-brace-offset -4)
	   (setq perl-brace-offset 0)
	   (setq perl-brace-imaginary-offset 0)
	   (setq perl-label-offset -2)
	   ; Make single-quotes work like double-quotes
	   (modify-syntax-entry ?' "\"" perl-mode-syntax-table)
	   )))

(setq perl-mode-hook cperl-mode-hook)

;;;;(setq perl-mode-hook cperl-mode-hook
;;;;      '(lambda ()
;;;;	 (progn
;;;;;	 (font-lock-mode nil)
;;;;	   (set-variable 'tab-width 8)
;;;;	   (setq perl-indent-level 4)
;;;;	   (setq perl-continued-statement-offset 4)
;;;;	   (setq perl-continued-brace-offset -4)
;;;;	   (setq perl-brace-offset 0)
;;;;	   (setq perl-brace-imaginary-offset 0)
;;;;	   (setq perl-label-offset -2)
;;;;	   )))

; Put gds files in text-mode automatically

; (add-to-list 'load-path "/Users/ericp/lab/emacs/scala-mode2")
; (require 'scala-mode2)

(setq auto-mode-alist
      (append '(("\\.doc$" . text-mode)
		("\\.gds$" . text-mode)
		("\\.txt$" . text-mode)
		("\\.xo[mn]$" . indented-text-mode)
		("\\.xtt?$" . indented-text-mode)
		("\\.xe[mt]$" . indented-text-mode) ; with external fns
		("\\.xtt?$" . indented-text-mode)
		("\\.nox$" . indented-text-mode)
		("\\.scr$" . indented-text-mode)
		("\\.xin$" . indented-text-mode)
		("\\.c?sh$" . indented-text-mode)
		("\\.c?mk$" . indented-text-mode)
		("\\.icn$" . indented-text-mode)
		("\\.exp$" . indented-text-mode)
		("\\.expi$" . indented-text-mode)
		("\\.vbs$" . indented-text-mode)
		("\\.c$" . c-mode)
		("\\.h$" . c++-mode)
		("\\.cpp$" . c++-mode)
		("\\.cxx$" . c++-mode)
		("\\.js$" . javascript-mode) ; emacs/js2.el sucks
		("\\.vue$" . indented-text-mode) ; emacs/js2.el sucks
		("\\.ts$" . typescript-mode) ; emacs/js2.el sucks
		("\\.cs$" . csharp-mode)
;@@@		("\\.py$" . python-mode)
;@@@		("\\.pyw$" . python-mode)
		("\\.pl$" . perl-mode)
		("\\.pm$" . perl-mode)
		("\\.t$" . perl-mode)
		("\\.rake$" . ruby-mode)
		("\\.ru$" . ruby-mode)
		("\\.go$" . go-mode)
		("\\.scala$" . scala-mode)
		("\\.sh$" . sh-mode)
		("\\.bash$" . sh-mode)
		)
	      auto-mode-alist))

; avoid Jim Clark's brain-dead sgml mode
(setq auto-mode-alist
      (append '(("\\.sgm$" . text-mode)
		("\\.dtd$" . text-mode)
		("\\.xul$" . text-mode)
		("\\.xml$" . text-mode)
		)
	      auto-mode-alist))

; (add-to-list 'load-path "/Users/ericp/emacs/go-mode.el")
; (setq gofmt-command "goimports")
; (add-to-list 'load-path "/Users/ericp/emacs/go-mode.el")
; (require 'go-mode-load)
; (add-hook 'before-save-hook 'gofmt-before-save)

; vi-hook
(setq vi-mode-hook
      '(lambda () (progn
		      (global-set-key "\e\e" 'vi-mode)
		      (setq vi-mode-hook nil))))

(setq python-mode-hook
      '(lambda()
	 (progn
	   (font-lock-fontify-buffer))))

(setq java-mode-hook
      '(lambda()
	 (progn
	   (set-variable 'tab-width 4)
	   (font-lock-fontify-buffer))))

(setq go-mode-hook
      '(lambda ()
	 (progn
	   (set-variable 'tab-width 4)
	   (setq gofmt-command "goimports")
	   (add-hook 'before-save-hook 'gofmt-before-save)
	   (setenv "GOPATH" "/Users/ericp/lab/gostuff" t)
	   (modify-syntax-entry ?_  "_") ; stop at underscores
	   )))

;; Here's a sample .emacs file that might help you along the way.  Just
;; copy this region and paste it into your .emacs file.  You may want to
;; change some of the actual values.

; From Emacs Info c-version 5.25

(defconst my-c-style
  '((c-tab-always-indent        . t)
    (c-comment-only-line-offset . 0)
    (c-hanging-braces-alist     . ((substatement-open after)
				   (brace-list-open)))
    (c-hanging-colons-alist     . ((member-init-intro before)
				   (inher-intro)
				   (case-label after)
				   (label after)
				   (access-label after)))
    (c-cleanup-list             . (scope-operator
				   empty-defun-braces
				   defun-close-semi))
    (c-offsets-alist            . ((arglist-close . c-lineup-arglist)
				   (substatement-open . 0)
				   (case-label        . 4)
				   (block-open        . 0)
				   (knr-argdecl-intro . -)))
    (c-echo-syntactic-information-p . t)
    )
  "My C Programming Style")

;; Customizations for all of c-mode, c++-mode, and objc-mode
(defun my-c-mode-common-hook ()
  ;; add my personal style and set it for the current buffer
  (c-add-style "PERSONAL" my-c-style t)
  ;; offset customizations not in my-c-style
  (c-set-offset 'member-init-intro '++)
  ;; other customizations
  (setq tab-width 4
	;; this will make sure spaces are used instead of tabs
	indent-tabs-mode nil)
  ;; we like auto-newline and hungry-delete
  ;;;;;;;;;;;;;;;; (c-toggle-auto-hungry-state 0) ; but I don't

  ;; keybindings for all supported languages.  We can put these in
  ;; c-mode-base-map because c-mode-map, c++-mode-map, objc-mode-map,
  ;; java-mode-map, and idl-mode-map inherit from it.
  ;; (define-key c-mode-base-map "\C-m" 'newline-and-indent)
  )

(add-hook 'c-mode-common-hook 'my-c-mode-common-hook)

; c-mode hook
(setq c-mode-hook
      '(lambda ()
	 (progn		; Problem with the next is that it skips mis-spellings.
	   (setq case-fold-search nil)
	   (setq case-replace t)
;	   (autoload 'c-comment "c-fill" nil t)
	   ; Exoterica Key bindings
	   (setq c-indent-level 4)
	   (setq c-continued-statement-offset 4)
	   (setq c-brace-offset -4)
	   (setq c-label-offset -2)
	   (setq c-argdecl-indent 4)
	   (setq c-auto-newline nil)	; Just not worth it
;	   (setq c-tab-always-indent nil)
	   (setq c-comment-starting-blank nil)
	   (font-lock-fontify-buffer)
; new C++ stuff
	   (c-set-offset 'substatement-open 0)
	   (c-set-offset (quote defun-block-intro) 3)
	   (c-set-offset (quote statement-block-intro) 3)
	   (c-set-offset 'block-open 0)
	   (c-set-offset (quote case-label) 2)
	   (c-set-offset (quote statement-case-intro) 1)
	   (setq tab-width 8)
	   )))

(setq shell-script-mode-hook
      '(lambda()fg
	 (progn
	   (custom-set-faces
	    ;; custom-set-faces was added by Custom.
	    ;; If you edit it by hand, you could mess it up, so be careful.
	    ;; Your init file should contain only one such instance.
	    ;; If there is more than one, they won't work right.
	    '(sh-heredoc ((t (:foreground "blue3")))))
	   )))

; c-mode hook
(setq c++-mode-hook
      '(lambda ()
	 (progn		; Problem with the next is that it skips mis-spellings.
	   (setq case-fold-search nil)
	   (setq case-replace t)
;	   (autoload 'c-comment "c-fill" nil t)
	   (setq c++-auto-hungry-initial-state 'none)
	   (setq c++-delete-function 'backward-delete-char)
	   (setq c++-empty-arglist-indent 4)
	   (setq c-indent-level 4)
	   (setq c-continued-statement-offset 4)
	   (setq c-brace-offset -4)
	   (setq c-label-offset -2)
	   (setq c-argdecl-indent 4)
	   (setq c-auto-newline nil)	; Just not worth it
;	   (setq c-tab-always-indent nil)
	   (setq c-comment-starting-blank nil)
	   (font-lock-fontify-buffer)
	   (set-variable 'tab-width 4)
	   )))

; how to get emacs to
(line-number-mode t)

(setq news-reply-mode-hook
      '(lambda ()
	 (progn
	   (define-key news-reply-mode-map "\C-c\C-c" 'auto-fill-mode)
	   (define-key news-reply-mode-map "\C-c\C-s" 'keyboard-quit))))

(put 'eval-expression 'disabled nil)

(fset 'next-c-function
  "^{")

(fset 'prev-c-function
   "xisearch-backward-regexp
^{")

(global-set-key "\e{" 'prev-c-function)
(global-set-key "\e}" 'next-c-function)

; Copies either the current line (no arg), the next n lines, or the prev. n
(defun copy-line (&optional arg)
  "Copy current line with no args, n (or -n,ending with current)
   with an arg.  Yank the lines back HyperTalk-editor style"
  (interactive "p")
  (setq last-command 'not-kill)		; avoid appending to previous kills
  (save-excursion
    (let ((locArg (or arg
		      1)))
      (end-of-line (if (> locArg 0)
		       0
		     nil))
      (let ((beg (point)))
	(forward-line locArg)
	(end-of-line)
	(copy-region-as-kill beg (point)))))
  (end-of-line))

(global-set-key "\ep" 'copy-line)

; register ?u
(set-register 118 "
	 (void) XTbe_Error (XTE?_???,
			    XTbe_RecError,
			    XTbe_ErrorBuf,
			    \"\",
			    \"\",
			    XTcf_GetFileName (XTcf_CurrentFile),
			    (int32) XTcf_GetLineNumber (XTcf_CurrentFile));
")

; registers a-c
;(set-register 97 "p_XTcl_LexicalTokenBuf")

; New, Improved!: now it kills the character at point, no matter what it is.
(defun new-zap-to-char (arg char)
  "Kill up to (but not including) ARG'th occurrence of CHAR.
Goes backward if ARG is negative; goes to end of buffer if CHAR not found."
  (interactive "*p\ncZap to char: ")
  (let ((arg (or arg 1)))
    (save-excursion
      (let ((k 2)) ; save-restriction doesn't work for some reason
	(unwind-protect
	    (kill-region
	     (point)
	     (progn
	       (goto-char (if (> arg 0) (1+ (point)) (point)))
	       (if (search-forward (char-to-string char) nil t arg)
		   (goto-char (if (> arg 0)
				  (1- (point))
				(1+ (point))))
		 (error "Character not found")))))))))

(global-set-key "\C-cz"	'new-zap-to-char)
(global-set-key "\C-cd"	'delete-rest-of-buffer)

(defun delete-rest-of-buffer ()
  "Deletes the rest of the buffer"
  (interactive)
  (save-excursion
    (kill-region (point) (point-max))))

(defun remove-fproto ()
  "Removed the prototypes in the region"
  (interactive)
  (save-excursion
    (save-restriction
      (narrow-to-region (region-beginning) (region-end))
      (goto-char (point-min))
      (replace-regexp "([^)]+);" "();" nil))))

(fset 'hw
   " ��delete-matching-lines
warning: possible pointer alignment problem
")

; things missing from 22.1 (!)
(global-set-key "\C-x/" 'point-to-register)
(global-set-key "\C-xj" 'jump-to-register)

(global-set-key "\C-xx" 'copy-to-register)
(global-set-key "\C-xg" 'insert-register)

(load-library "time")
(display-time)


; Don't like the way they redefined the ctrl-z key here.
  (setq view-mode-map (make-keymap))
;;;;  (fillarray view-mode-map 'undefined)
  (define-key view-mode-map "\C-c" 'exit-recursive-edit)
  (define-key view-mode-map "q" 'exit-recursive-edit)
  (define-key view-mode-map "-" 'negative-argument)
  (define-key view-mode-map "0" 'digit-argument)
  (define-key view-mode-map "1" 'digit-argument)
  (define-key view-mode-map "2" 'digit-argument)
  (define-key view-mode-map "3" 'digit-argument)
  (define-key view-mode-map "4" 'digit-argument)
  (define-key view-mode-map "5" 'digit-argument)
  (define-key view-mode-map "6" 'digit-argument)
  (define-key view-mode-map "7" 'digit-argument)
  (define-key view-mode-map "8" 'digit-argument)
  (define-key view-mode-map "9" 'digit-argument)
  (define-key view-mode-map "\C-u" 'universal-argument)
  (define-key view-mode-map "\e" nil)
  (define-key view-mode-map "\C-x" 'Control-X-prefix)
  (define-key view-mode-map "\e-" 'negative-argument)
  (define-key view-mode-map "\e0" 'digit-argument)
  (define-key view-mode-map "\e1" 'digit-argument)
  (define-key view-mode-map "\e2" 'digit-argument)
  (define-key view-mode-map "\e3" 'digit-argument)
  (define-key view-mode-map "\e4" 'digit-argument)
  (define-key view-mode-map "\e5" 'digit-argument)
  (define-key view-mode-map "\e6" 'digit-argument)
  (define-key view-mode-map "\e7" 'digit-argument)
  (define-key view-mode-map "\e8" 'digit-argument)
  (define-key view-mode-map "\e9" 'digit-argument)
  (define-key view-mode-map "<" 'beginning-of-buffer)
  (define-key view-mode-map ">" 'end-of-buffer)
  (define-key view-mode-map "\ev" 'View-scroll-lines-backward)
  (define-key view-mode-map "\C-v" 'View-scroll-lines-forward)
  (define-key view-mode-map "\C-z" 'scroll-one-line-up)
  (define-key view-mode-map " " 'View-scroll-lines-forward)
  (define-key view-mode-map "\177" 'View-scroll-lines-backward)
  (define-key view-mode-map "\n" 'View-scroll-one-more-line)
  (define-key view-mode-map "\r" 'View-scroll-one-more-line)
  (define-key view-mode-map "\C-l" 'recenter)
  (define-key view-mode-map "z" 'View-scroll-lines-forward-set-scroll-size)
  (define-key view-mode-map "g" 'View-goto-line)
  (define-key view-mode-map "=" 'what-line)
  (define-key view-mode-map "." 'set-mark-command)
  (define-key view-mode-map "\C-@" 'set-mark-command)
  (define-key view-mode-map "'" 'View-back-to-mark)
  (define-key view-mode-map "@" 'View-back-to-mark)
  (define-key view-mode-map "x" 'exchange-point-and-mark)
  (define-key view-mode-map "h" 'Helper-describe-bindings)
  (define-key view-mode-map "?" 'Helper-describe-bindings)
  (define-key view-mode-map "\C-h" 'Helper-help)
;  (define-key view-mode-map "\C-n" 'View-next-line)
;  (define-key view-mode-map "\C-p" 'View-previous-line)
  (define-key view-mode-map "\C-s" 'isearch-forward)
  (define-key view-mode-map "\C-r" 'isearch-backward)
  (define-key view-mode-map "s" 'isearch-forward)
  (define-key view-mode-map "r" 'isearch-backward)
  (define-key view-mode-map "/" 'View-search-regexp-forward)
  (define-key view-mode-map "\\" 'View-search-regexp-backward)
  ;; This conflicts with the standard binding of isearch-regexp-forward
  (define-key view-mode-map "\e\C-s" 'View-search-regexp-forward)
  (define-key view-mode-map "\e\C-r" 'View-search-regexp-backward)
  (define-key view-mode-map "n" 'View-search-last-regexp-forward)
  (define-key view-mode-map "p" 'View-search-last-regexp-backward)

;;;;  (define-key isearch-mode-map "\C-m" 'isearch-other)
  (define-key isearch-mode-map "\ep" 'isearch-other-control-char)

(when (>= emacs-major-version 24)
  (progn
    (setq isearch-mode-hook
	  '(lambda nil
	     (progn
	       (define-key isearch-mode-map "\C-y" 'isearch-yank-line))))
    ; Brain-dead v24.3 reversed the meaning of these *functions*
    ; rather than change the key assignments.
    (global-set-key "\C-m" 'electric-newline-and-maybe-indent)
    (global-set-key "\C-j" 'newline)
    ))

; redefinition of zap-to-char (emacs 19.29 seems to have goofed)
; the 1- point line was commented out in simple.el -- big undocumented goof

(defun zap-to-char (arg char)
  "Kill up to and including ARG'th occurrence of CHAR.
Goes backward if ARG is negative; error if CHAR not found."
  (interactive "p\ncZap to char: ")
  (kill-region (point) (progn
                         (search-forward (char-to-string char) nil nil arg)
                         (goto-char (if (> arg 0) (1- (point)) (1+ (point))))
                         (point))))

; To have Emacs automatically uncompress compressed files add the
; following to your '.emacs' file:

					; (require 'jka-compr)

;@@@ (load "~/emacs/python-mode.el")

(put 'downcase-region 'disabled nil)

(server-start)

; (if (eq window-system 'x)
;     (progn
;       (add-hook 'server-switch-hook 'make-frame)
;       (add-hook 'server-done-hook 'delete-frame)))

(fset 'yes-or-no-p 'y-or-n-p)

; (load-file "/Users/ericp/emacs/psvn.el")

(set-variable 'scroll-bar-mode 'right)
(set-variable 'transient-mark-mode nil)
(toggle-scroll-bar 1)

(put 'upcase-region 'disabled nil)

(defun chmod-off ()
  (interactive)
  (save-excursion
    (unwind-protect
	(progn
	  (shell-command (concat "chmod -w " (buffer-file-name)))
	  (revert-buffer t t)
	  )
      )
    )
  )

(defun chmod-on ()
  (interactive)
  (save-excursion
    (unwind-protect
	(progn
	  (shell-command (concat "chmod +w " (buffer-file-name)))
	  (revert-buffer t t)
	  )
      )
    )
  )


; (set-default-font "-*-Lucida Console-normal-r-*-*-11-*-96-96-c-*-iso8859-1")


;79 dots and a semi-colon: try to ensure an 80-char-wide screen
;...............................................................................

(tool-bar-mode 0)
(shell)
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(display-time-mode t)
 '(cua-delete-selection nil)
 '(delete-selection-mode nil)
 '(tool-bar-mode nil)
 '(transient-mark-mode nil))

;(when (>= emacs-major-version 24)
;  (custom-set-faces
   ;; custom-set-faces was added by Custom.
   ;; If you edit it by hand, you could mess it up, so be careful.
   ;; Your init file should contain only one such instance.
   ;; If there is more than one, they won't work right.
;   '(default ((t (:family "DejaVu Sans Mono" :foundry "unknown" :slant normal :weight normal :height 98 :width normal))))))

(delete-selection-mode nil)

(setq default-directory "~/")
(setq command-line-default-directory "~/")

(setq ring-bell-function 'ignore)

;;;; Can't make this work...
;;;; (setq my-delete-selection-mode-hook
;;;;       '(lambda ()
;;;; 	 (progn
;;;; 	   (global-set-key "\C-d" 'delete-char)
;;;; 	   (global-set-key "" 'delete-backward-char)
;;;; 	   (set-variable 'delete-selection-mode nil)
;;;; 	   (set-variable 'transient-mark-mode nil)
;;;; 	   (set-variable 'cua-delete-selection nil)
;;;; 	   )
;;;; 	 )
;;;;       )
;;;; 
;;;; (when (>= emacs-major-version 24)
;;;;   (add-hook 'delete-selection-mode-hook 'my-delete-selection-mode-hook))
