
;;; omnimark-mode.el --- major mode for editing Omnimark scripts

;; Copyright (c) 1995 Daniel Speck

;;; $Id: omnimark-mode.el,v 1.8 1995-11-02 08:33:04-05 ds4359 Exp $

;; Author: Daniel Speck <dspeck@bna.com>
;; Created: 25 July 1995
;; Version: $Revision: 1.8 $
;; Keywords: languages, omnimark, sgml

;;; This file is not part of GNU Emacs.

;;; This program is free software; you can redistribute it and/or modify
;;; it under the terms of the GNU General Public License as published by
;;; the Free Software Foundation; either version 2, or (at your option)
;;; any later version.

;;; This program is distributed in the hope that it will be useful,
;;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;; GNU General Public License for more details.

;;; You should have received a copy of the GNU General Public License
;;; along with GNU Emacs; see the file COPYING.  If not, write to
;;; the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, =
USA.

;;; Commentary:

;; Purpose:
;;
;; This package provides a major mode for editing Omnimark scripts.
;;

;;; Change log:

;; $Log: omnimark-mode.el,v $
;; Revision 1.8  1995-11-02 08:33:04-05  ds4359
;; Many changes, too numerous to enumerate.
;;
;; Revision 1.7  1995-09-15 17:41:06-04  ds4359
;; Just check-pointing the current development because I plan to make =
some
;; changes that I might want to back out.
;;
;; Revision 1.6  1995-09-08 15:31:33-04  ds4359
;; Added a few more keywords, etc.
;;
;; Revision 1.5  1995-09-08 11:00:06-04  ds4359
;; Lots of changes, too numerous to mention.
;;
;; Revision 1.4  1995-09-07 17:24:51-04  ds4359
;; Added SIZE keyword.
;;
;; Revision 1.3  1995-09-07 17:20:08-04  ds4359
;; Added a few more omnimark keywords.
;;
;; Revision 1.2  1995-09-07 15:50:09-04  ds4359
;; Added code support font-lock-mode.
;;
;; Revision 1.1  1995-09-05 10:40:11-04  ds4359
;; Initial revision

;;; Code:

(provide 'omnimark-mode)

(require 'compile)
(require 'font-lock)

(autoload 'make-regexp "make-regexp")

(defvar omnimark-mode-syntax-table nil
  "Syntax table used while in Omnimark mode.")

(if omnimark-mode-syntax-table
    ()
  (setq omnimark-mode-syntax-table (make-syntax-table))
  ;;
  ;; double and single quote are string-quote characters
  ;;
  (modify-syntax-entry ?\" "\"   " omnimark-mode-syntax-table)
  (modify-syntax-entry ?'  "\"   " omnimark-mode-syntax-table)
  ;;
  ;; percent is an escape character that affects the following =
character(s)
  ;;
  (modify-syntax-entry ?%  "/   " omnimark-mode-syntax-table)
  ;;
  ;; treat backslash as a punctuation character
  ;;
  (modify-syntax-entry ?\\  ".   " omnimark-mode-syntax-table)
  ;;
  ;; open paren is an open delimiter, close paren is a close delimiter
  ;;
  (modify-syntax-entry ?\( "()  " omnimark-mode-syntax-table)
  (modify-syntax-entry ?\) ")(  " omnimark-mode-syntax-table)
  ;;
  ;; semi-colon starts a comment, newline ends it
  ;;
  (modify-syntax-entry ?\; "<   " omnimark-mode-syntax-table)
  (modify-syntax-entry ?\n ">   " omnimark-mode-syntax-table)
  ;;
  ;; periods, hyphens and underscores can occur in symbols
  ;;
  (modify-syntax-entry ?. "_   " omnimark-mode-syntax-table)
  (modify-syntax-entry ?- "_   " omnimark-mode-syntax-table)
  (modify-syntax-entry ?_ "_   " omnimark-mode-syntax-table)
  ;;
  ;; # can occur at start of identifiers (e.g., #ERROR, #CONSOLE, =
#FIRST, ...)
  ;;
  (modify-syntax-entry ?# "'   " omnimark-mode-syntax-table)
)

;;; omnimark-keywords contains a list of the keywords in the Omnimark =
language
(defconst omnimark-keywords=20
  '("activate" "active" "again" "ancestor" "and" "another" "any" =
"any-text"=20
    "#appinfo" "arg" "attached" "attribute"=20
    "base" "binary" "binary-input" "binary-output" "blank" "break-width" =
=20
    "buffer" "by"
    "cdata" "children" "clear" "close" "closed" "complement" "#console"
    "content-end" "content-start" "content" "context-translate" "copy"
    "copy-clear" "counter"=20
    "data-attribute" "date" "deactivate" "decrement" "defaulted" =
"delimiter"
    "difference" "digit" "discard" "do" "doctype" "document-end"
    "document-start" "#done" "domain-free" "done" "down-translate"
    "element" "else" "entity" "equal" "#error" "escape" "except" "exit"=20
    "external-entity"=20
    "file" "find-end" "find-start" "find" "#first"
    "global" "greater-equal" "greater-than" "group"=20
    "halt" "has"
    "#implied" "in-library" "include" "inclusion" "increment" =
"insertion-break"
    "is" "isnt" "#item" "item"
    "key" "keyed"=20
    "#last" "last" "lc" "length" "less-equal" "less-than" "letters" =
"library"=20
    "literal" "line-end" "line-start" "local" "lookahead"=20
    "macro-end" "macro" "mask" "match" "modulo"=20
    "namecase" "named" "new" "newline" "next" "non-cdata" "non-sdata" =
"not"=20
    "notation" "number"=20
    "occurrence" "of" "open" "or" "#output" "output" "output-to" "over"=20
    "parent" "pattern" "pcdata" "preparent" "previous" =
"processing-instruction"
    "proper" "public" "put"=20
    "referents" "referent" "referents-allowed" "remove" "reopen" =
"repeat"=20
    "replacement-break" "reset"
    "save" "save-clear" "scan" "set" "sdata" "sgml" "sgml-error" =
"sgml-in"=20
    "sgml-out" "shift" "size" "space" "specified" "status" "stream" =
"submit"=20
    "#suppress"=20
    "suppress" "switch" "symbol" "system" "system-call"=20
    "text" "this" "token" "to" "translate"
    "uc" "ul" "unanchored" "union" "unless" "up-translate" "using"=20
    "value" "valued" "value-end" "value-start" "variable"
    "when" "white-space" "word-end" "word-start")
  "List of Omnimark keywords.")

(defvar omnimark-mode-abbrev-table nil
  "Abbrev table used while in Omnimark mode.")

;;; define omnimark-mode-abbrev-table if not already defined
(if omnimark-mode-abbrev-table
    ()
  ;; remember current state of abbrevs-changed so we can restore it =
after
  ;; defining some abbrevs
  (let ((ac abbrevs-changed))
    (define-abbrev-table 'omnimark-mode-abbrev-table ())
    (define-abbrev omnimark-mode-abbrev-table "ele"	"ELEMENT"	nil)
    (define-abbrev omnimark-mode-abbrev-table "spe"	"SPECIFIED"	nil)
    (define-abbrev omnimark-mode-abbrev-table "tra"	"TRANSLATE"	nil)
    (define-abbrev omnimark-mode-abbrev-table "dw"	"DO WHEN"	nil)
    (define-abbrev omnimark-mode-abbrev-table "att"	"ATTRIBUTE"	nil)
    (define-abbrev omnimark-mode-abbrev-table "buf"	"BUFFER"	nil)
    (define-abbrev omnimark-mode-abbrev-table "swi"	"SWITCH"	nil)
    (define-abbrev omnimark-mode-abbrev-table "cou"	"COUNTER"	nil)
    (define-abbrev omnimark-mode-abbrev-table "str"	"STREAM"	nil)

    ;; this is a little TOO much abbreving
;;;;;    (let ((kw omnimark-keywords))
;;;;;      (while kw
;;;;;	(define-abbrev omnimark-mode-abbrev-table (car kw) (upcase (car =
kw)) nil)
;;;;;	(setq kw (cdr kw))
;;;;;	)
;;;;;      )
    (setq abbrevs-changed ac)))

(defvar omnimark-mode-map nil
  "Keymap for Omnimark mode.")

(if omnimark-mode-map
    ()
  (setq omnimark-mode-map (make-sparse-keymap))
  (define-key omnimark-mode-map [tab]	  'electric-omnimark-tab)
  (define-key omnimark-mode-map "\177"	  'backward-delete-char-untabify)
  (define-key omnimark-mode-map "\M-\C-e" 'omnimark-next-rule)
  (define-key omnimark-mode-map "\M-\C-a" 'omnimark-previous-rule)
  (define-key omnimark-mode-map "\M-\C-h" 'mark-omnimark-rule)
  )

;;; omnimark-rule-starts holds a list of all keywords that can start =
rules
(defconst omnimark-rule-starts=20
  '(
    ;; element domain rules
    "data-content" "document-end" "document-start" "dtd-end" "element"
    "epilog-start" "external-data-entity" "external-entity"
    "marked-section" "otherwise" "processing-instruction" "prolog-end"
    "sgml-comment" "sgml-declaration-end" "translate"
   =20
    ;; find domain rules
    "find-start" "find-end" "find" "external-text-entity"

    ;; error rule
    "sgml-error"

    ;; declarations
    "down-translate" "up-translate" "cross-translate" =
"context-translate"
    "insertion-break" "replacement-break" "break-width"

    ;; miscellaneous=20
    "include"
    )
  "List of all strings that can start an Omnimark rule.")

(defconst omnimark-rule-start-re=20
  (concat "^[ \t]*" (make-regexp omnimark-rule-starts t))
  "Regular expression matching all strings that start an Omnimark rule."
)

(defconst omnimark-identifier "[a-zA-Z][-.a-zA-Z0-9_]*"
  "Regular expression representing Omnimark identifiers.")

;;; Font lock stuff

;; This is the basic level of fontification: it handles all Omnimark
;; rule types, variable declarations, and macro definitions. This is
;; in addition to whatever is done by the syntactic fontification.

(defconst omnimark-font-lock-keywords-1
    (list=20
     ;; Omnimark rule starts
     (list omnimark-rule-start-re '(1 font-lock-function-name-face t))

     ;; Variable declarations
     (list
      (concat "^\\s-*"=20
	      "\\(local\\|global\\)" "\\s-+"
	      "\\(stream\\|counter\\|switch\\)" "\\s-+"
	      "\\(" omnimark-identifier "\\)"=20
	      "\\(" "\\s-+" "\\(size\\|variable\\)" "\\)?"
	      )
      '(1 font-lock-keyword-face t)
      '(2 font-lock-keyword-face t)
      '(3 font-lock-variable-name-face t)
      '(5 font-lock-keyword-face t t))

     ;; Macro declarations
     (list
      (concat "^[ \t]*\\(macro\\)\\s-+\\(" omnimark-identifier "\\)" )
      '(1 font-lock-keyword-face t) '(2 font-lock-variable-name-face t))
     ))

;; This is the full level of fontification: it does everything that
;; the basic level does plus all Omnimark keywords.

(defconst omnimark-font-lock-keywords-2
  (append=20
   omnimark-font-lock-keywords-1
   (list
     ;; Omnimark keywords
     (list
      (concat "\\(\\s-\\|^\\)\\("=20
	      (make-regexp omnimark-keywords)
	      "\\)\\>")
      '(2 font-lock-keyword-face))
     )))

;; If font-lock-maximum-decoration is non-nil, do all decorations.
(defvar omnimark-font-lock-keywords=20
  (if font-lock-maximum-decoration
      omnimark-font-lock-keywords-2
    omnimark-font-lock-keywords-1))

;;; included auto indent code (largely hacked from pascal.el)

;;
;; Regular expressions used to calculate indent, etc.
;;
(defconst omnimark-symbol-re      "\\<[a-zA-Z_][-a-zA-Z_0-9.]*\\>")
(defconst omnimark-beg-block-re   "\\<\\(do\\|repeat\\|macro\\)\\>")
(defconst omnimark-end-block-re   =
"\\<\\(done\\|again\\|macro-end\\)\\>")
(defconst omnimark-declaration-re "\\<\\(local\\|global\\)\\>")
(defconst omnimark-defun-re       omnimark-rule-start-re)
(defconst omnimark-sub-block-re   "\\<\\(else\\|match\\|using\\)\\>")
(defconst omnimark-noindent-re    =
"\\<\\(do\\|done\\|repeat\\|again\\|else\\)\\>")

(defconst omnimark-action-starts=20
  '("do" "done" "repeat" "again" "else" "exit"
    "new" "clear" "remove" "copy" "copy-clear"
    "set" "reset" "increment" "decrement" "activate" "deactivate"
    "open" "reopen" "close" "discard" "put" "output" "output-to"
    "submit"
    "match" "scan"
    "next"
    )
)
(defconst omnimark-autoindent-lines-re
  (concat "\\<" (make-regexp omnimark-action-starts t) "\\>"))

(defvar omnimark-indent-level 2
  "*Indentation of Omnimark actions with respect to containing block.")

(defvar omnimark-rule-indent 4
  "*Indentation of Omnimark actions with respect to containing rule.")

(defvar omnimark-auto-newline nil
  "*Non-nil means automatically newline after simcolons and the =
punctation mark
after an end.")

(defvar omnimark-tab-always-indent t
  "*Non-nil means TAB in Omnimark mode should always reindent the =
current line,
regardless of where in the line point is when the TAB command is used.")

(defvar omnimark-auto-lineup '(all)
  "*List of contexts where auto lineup of :'s or =3D's should be done.
Elements can be of type: 'paramlist', 'declaration' or 'case', which =
will
do auto lineup in parameterlist, declarations or case-statements
respectively. The word 'all' will do all lineups. '(case paramlist) for
instance will do lineup in case-statements and parameterlist, while =
'(all)
will do all lineups.")

(defvar omnimark-type-keywords
  '("counter" "switch" "stream" "local" "global")
  "*Keywords for types used when completing a word in a declaration or =
parmlist.
\(eg. integer, real, char.)  The types defined within the Omnimark =
program
will be completed runtime, and should not be added to this list.")

(defvar omnimark-start-keywords
  '("begin" "end" "function" "procedure" "repeat" "until" "while"
    "read" "readln" "reset" "rewrite" "write" "writeln")
  "*Keywords to complete when standing at the first word of a statement.
\(eg. begin, repeat, until, readln.)
The procedures and variables defined within the Omnimark program
will be completed runtime and should not be added to this list.")

(defvar omnimark-separator-keywords
  '("downto" "else" "mod" "div" "then")
  "*Keywords to complete when NOT standing at the first word of a =
statement.
\(eg. downto, else, mod, then.)=20
Variables and function names defined within the
Omnimark program are completed runtime and should not be added to this =
list.")

;;;
;;;  Macros
;;;

(defsubst omnimark-get-beg-of-line (&optional arg)
  (save-excursion
    (beginning-of-line arg)
    (point)))

(defsubst omnimark-get-end-of-line (&optional arg)
  (save-excursion
    (end-of-line arg)
    (point)))

(defun omnimark-declaration-end ()
  (let ((nest 1))
    (while (and (> nest 0)
		(re-search-forward=20
		 "[:=3D]\\|\\(\\<record\\>\\)\\|\\(\\<end\\>\\)"=20
		 (save-excursion (end-of-line 2) (point)) t))
      (cond ((match-beginning 1) (setq nest (1+ nest)))
	    ((match-beginning 2) (setq nest (1- nest)))))))


(defun omnimark-declaration-beg ()
  (let ((nest 1))
    (while (and (> nest 0)
		(re-search-backward =
"[:=3D]\\|\\<\\(type\\|var\\|label\\|const\\)\\>\\|\\(\\<record\\>\\)\\|\=
\(\\<end\\>\\)" (omnimark-get-beg-of-line 0) t))
      (cond ((match-beginning 1) (setq nest 0))
	    ((match-beginning 2) (setq nest (1- nest)))
	    ((match-beginning 3) (setq nest (1+ nest)))))
    (=3D nest 0)))

 =20
(defsubst omnimark-within-string ()
  (save-excursion
    (nth 3 (parse-partial-sexp (omnimark-get-beg-of-line) (point)))))

(defun electric-omnimark-terminate-line ()
  "Terminate line and indent next line."
  (interactive)
  ;; First, check if current line should be indented
  (save-excursion
    (beginning-of-line)
    (skip-chars-forward " \t")
    (if (looking-at omnimark-autoindent-lines-re)
	(omnimark-indent-line)))
  (delete-horizontal-space) ; Removes trailing whitespaces
  (newline)
  ;; Indent next line
  (omnimark-indent-line)
  ;; Maybe we should set some endcomments
;  (if omnimark-auto-endcomments
;      (omnimark-set-auto-comments))
  ;; Check if we shall indent inside comment
  (let ((setstar nil))
    (save-excursion
      (forward-line -1)
      (skip-chars-forward " \t")
      (cond ((looking-at "\\*[ \t]+)")
	     ;; Delete region between `*' and `)' if there is only whitespaces.
	     (forward-char 1)
	     (delete-horizontal-space))
	    ((and (looking-at "(\\*\\|\\*[^)]")
		  (not (save-excursion
			 (search-forward "*)" (omnimark-get-end-of-line) t))))
	     (setq setstar t))))
    ;; If last line was a star comment line then this one shall be too.
    (if (null setstar)=09
	(omnimark-indent-line)
      (insert "*  "))))

(defun electric-omnimark-tab ()
  "Function called when TAB is pressed in Omnimark mode."
  (interactive)
  ;; Do nothing if within a string or in a CPP directive.
  (if (or (omnimark-within-string)
	  (and (not (bolp))
	       (save-excursion (beginning-of-line) (eq (following-char) ?#))))
      (insert "\t")
    ;; If omnimark-tab-always-indent, indent the beginning of the line.
    (if omnimark-tab-always-indent
	(save-excursion
	  (beginning-of-line)
	  (omnimark-indent-line))
      (insert "\t"))
    (omnimark-indent-command)))

=0C

;;;
;;; Interactive functions
;;;
(defun omnimark-insert-block ()
  "Insert Omnimark do ... done block in the code with right =
indentation."
  (interactive)
  (omnimark-indent-line)
  (insert "do")
  (electric-omnimark-terminate-line)
  (save-excursion
    (electric-omnimark-terminate-line)
    (insert "done")
    (beginning-of-line)
    (omnimark-indent-line)))

(defun omnimark-downcase-keywords ()
  "Downcase all Omnimark keywords in the buffer."
  (interactive)
  (omnimark-change-keywords 'downcase-word))

(defun omnimark-upcase-keywords ()
  "Upcase all Omnimark keywords in the buffer."
  (interactive)
  (omnimark-change-keywords 'upcase-word))

(defun omnimark-capitalize-keywords ()
  "Capitalize all Omnimark keywords in the buffer."
  (interactive)
  (omnimark-change-keywords 'capitalize-word))

;; Change the keywords according to argument.
(defun omnimark-change-keywords (change-word)
  (save-excursion
    (let ((keyword-re (concat "\\<\\("
			      (mapconcat 'identity omnimark-keywords "\\|")
			      "\\)\\>")))
      (goto-char (point-min))
      (while (re-search-forward keyword-re nil t)
	(funcall change-word -1)))))

;;;
;;; Indentation
;;;
(defconst omnimark-indent-alist
  '((block	. (+ ind omnimark-indent-level))
    (cpp	. 0)
    (declaration . (+ ind omnimark-indent-level))
    (comment	. (omnimark-indent-comment t))
    (defun	. ind)=20
    (rule	. omnimark-rule-indent)=20
    (contexp	. ind)
    (unknown	. 12)=20
    (string	. 0)))

(defun omnimark-indent-command ()
  "Indent for special part of code."
  (let* ((indent-str (omnimark-calculate-indent))
	 (type (car indent-str))
	 (ind (car (cdr indent-str))))
    (if (looking-at "[ \t]+$")
	(skip-chars-forward " \t"))))

(defun omnimark-indent-line ()
  "Indent current line as a Omnimark statement."
  (let* ((indent-str (omnimark-calculate-indent))
	 (type (car indent-str))
	 (ind (car (cdr indent-str))))
    (message=20
     (format "omnimark-indent-line: indent-str=3D%s type=3D%s, ind=3D%d" =
indent-str type ind))
;    (if (looking-at "^[0-9a-zA-Z]+[ \t]*:[^=3D]")
;	(search-forward ":" nil t))
    (delete-horizontal-space)
    ;; Some things should not be indented
    (cond=20
     ((looking-at omnimark-rule-start-re)
;    (if (or ;(and (eq type 'declaration) (looking-at =
omnimark-declaration-re))
;	     ;(eq type 'cpp)
;	     ;(looking-at omnimark-defun-re)
      (progn
	(message "matched omnimark-rule-start-re")
	()
	))
     ;; Omnimark actions at rule level
     ((eq type 'rule)
      (progn
	(message "matched type =3D rule")
	 (indent-to omnimark-rule-indent)
	 )
      )
     ;; Other things should have no extra indent
     ((and (eq type 'block)
	   (looking-at "\\(else\\|match\\|done\\)")
	   )
      (progn
	(message "matched ELSE, DONE or MATCH")
	(indent-to=20
	 (- (eval (cdr (assoc type omnimark-indent-alist)))=20
	    omnimark-indent-level)
	 )
	)
      )
     ;; But most lines are treated this way:
     (t=20
      (progn
	(message "matched t in cond")
	(indent-to (eval (cdr (assoc type omnimark-indent-alist))))))
     )))

=0C
(defun omnimark-calculate-indent ()
  "Calculate the indent of the current Omnimark line.
Return a list of two elements: (INDENT-TYPE INDENT-LEVEL)."
  (save-excursion
    (let* ((oldpos (point))
	   (state (save-excursion (parse-partial-sexp (point-min) (point))))
	   (nest 0)=20
	   (par 0)=20
	   (complete (looking-at "[ \t]*\\(done\\|again\\)\\>"))
	   (elsed (looking-at "[ \t]*else\\>"))
	   (type (catch 'nesting
		   ;; Check if inside a string, comment or parenthesis
		   (cond ((nth 3 state) (throw 'nesting 'string))
			 ((nth 4 state) (throw 'nesting 'comment))
			 ((> (car state) 0)
			  (goto-char (scan-lists (point) -1 (car state)))
			  (setq par (1+ (current-column))))
			 )
		   ;; Loop until correct indent is found
		   (while t
		     (backward-sexp 1)
		     (cond=20
		      (;--Nest block outwards
		       (looking-at omnimark-beg-block-re)
		       (if (=3D nest 0)
			   (cond ((looking-at "\\(repeat\\|do\\) scan\\>")
				  (throw 'nesting 'case))
				 (t (throw 'nesting 'block)))
			 (setq nest (1- nest))))
		      (;--Nest block inwards
		       (looking-at omnimark-end-block-re)
		       (if (and (looking-at "\\(done\\|again\\)\\s ")
				elsed=20
				(not complete))
			   (throw 'nesting 'block))
		       (setq complete t
			     nest (1+ nest)))
		      (;--Omnimark rule start
		       (looking-at omnimark-rule-start-re)
		       (throw 'nesting 'rule)
		       )
		      (;--Defun (or parameter list)
		       (looking-at omnimark-defun-re)
		       (if (=3D 0 par)
			   (throw 'nesting 'defun)
			 (setq par 0))
		       )
		      (;--If, else or while statement
		       (and (not complete)
			    (looking-at omnimark-sub-block-re))
		       (throw 'nesting 'block))
;		      (;--Found complete statement
;		       (save-excursion (forward-sexp 1)
;				       (=3D (following-char) ?\;))
;		       (setq complete t))
		      (;--No known statements
		       (bobp)
		       (throw 'nesting 'unknown))
		      )))))

      ;; Return type of block and indent level.
      (if (> par 0)                               ; Unclosed Parenthesis =
=20
	  (list 'contexp par)
	(list type (omnimark-indent-level))))))

(defun omnimark-indent-level ()
  "Return the indent-level the current statement has.
Do not count labels, case-statements or records."
  (save-excursion
    (beginning-of-line)
    (skip-chars-forward " \t")
    (current-column)))

(defun omnimark-indent-comment (&optional arg)
  "Indent current line as comment.
If optional arg is non-nil, just return the
column number the line should be indented to."
    (let* ((stcol (save-excursion
		    (re-search-backward "(\\*\\|{" nil t)
		    (1+ (current-column)))))
      (if arg stcol
	(delete-horizontal-space)
	(indent-to stcol))))

;;;; end of included stuff
   =20
=0C				=09
;;; move to next rule in buffer
(defun omnimark-next-rule ()
  "Function to position the cursor at the beginning of the next rule in =
an
Omnimark script."
  (interactive)
  (forward-char)
  (if (re-search-forward omnimark-rule-start-re nil t)
      (goto-char (match-beginning 1))
    (progn (backward-char)	; move back to the character we started on
	   (error "No more rules"))))

;;; move to previous rule in buffer
(defun omnimark-previous-rule ()
  "Function to position the cursor at the beginning of the previous rule =
in an
Omnimark script."
  (interactive)
  (if (re-search-backward omnimark-rule-start-re nil t)
      (goto-char (match-beginning 1))
    (error "No more rules")))

;;; mark current or next omnimark rule in the buffer
(defun mark-omnimark-rule ()
  "Put mark at end of current rule, point at beginning."
  (interactive)
  (push-mark (point))
  (omnimark-next-rule)
  ;; back up over up to 100 comment lines
  (forward-comment -100)
  (push-mark (point) nil t)
  (omnimark-previous-rule))
=0C
;;;###autoload
(defun omnimark-mode ()
  "Major mode for editing Omnimark scripts.

Special commands:
\\{omnimark-mode-map}
Turning on Omnimark mode calls the value of the variable =
`omnimark-mode-hook',
if that value is non-nil.

Font lock mode:

Turning on font lock mode causes various Omnimark syntactic structures =
to be=20
hightlighted. To turn this on whenever you visit an Omnimark file, add
the following to your .emacs file:
  \(add-hook 'omnimark-mode-hook 'turn-on-font-lock\)
"
  (interactive)
  (kill-all-local-variables)
  (use-local-map omnimark-mode-map)
  (setq mode-name "Omnimark")
  (setq major-mode 'omnimark-mode)
  (setq local-abbrev-table omnimark-mode-abbrev-table)
  ;; comment stuff
  (make-local-variable 'comment-column)
  (setq comment-column 32)
  (make-local-variable 'comment-start)
  (setq comment-start "; ")
  (make-local-variable 'comment-end)
  (setq comment-end "\n")
  (make-local-variable 'comment-start-skip)
  (setq comment-start-skip ";;* *")
  ;;
  ;; later we should move this into the omnimark-mode-hook in
  ;; our local .emacs file
  ;; (abbrev-mode t)
  ;;
  (make-local-variable 'font-lock-defaults)
  (setq font-lock-defaults=20
	'(omnimark-font-lock-keywords nil t ((?- . "w")
					     (?_ . "w")
					     (?. . "w"))))
  ;; add an entry to compilation-error-regexp-alist for Omnimark
  ;; compiler errors
  (setq compilation-error-regexp-alist
	(cons '("OmniMark Error on line \\([0-9]*\\) in file \\(.*\\):$" 2 1)
	      compilation-error-regexp-alist))

  (set-syntax-table omnimark-mode-syntax-table)
  (run-hooks 'omnimark-mode-hook)
)

;;; omnimark-mode.el ends here
--2354_3f66-5d93_7774-4097_6ffe
Content-Type: application/octet-stream; name=make-regexp.el
Content-Transfer-Encoding: quoted-printable
Content-MD5: 2B8lpvglTjUqXsGeqfG8fw==
Content-Description: make-regexp.el
Content-Disposition: attachment; filename=make-regexp.el

;;; make-regexp.el --- generate efficient regexps to match strings.

;; Copyright (C) 1994, 1995 Simon Marshall.

;; Author: Simon Marshall <simon@gnu.ai.mit.edu>
;; Keywords: strings, regexps
;; Version: 1.02

;; LCD Archive Entry:
;; make-regexp|Simon Marshall|simon@gnu.ai.mit.edu|
;; Generate efficient regexps to match strings.|
;; 11-Jul-1995|1.02|~/functions/make-regexp.el.gz|

;; The archive is archive.cis.ohio-state.edu in =
/pub/gnu/emacs/elisp-archive.

;;; This file is not part of GNU Emacs.

;;; This program is free software; you can redistribute it and/or modify
;;; it under the terms of the GNU General Public License as published by
;;; the Free Software Foundation; either version 2, or (at your option)
;;; any later version.

;;; This program is distributed in the hope that it will be useful,
;;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;; GNU General Public License for more details.

;;; You should have received a copy of the GNU General Public License
;;; along with GNU Emacs; see the file COPYING.  If not, write to
;;; the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, =
USA.

;;; Commentary:

;; Purpose:
;;
;; To make efficient regexps from lists of strings.

;; For example:
;;
;; (let ((strings '("cond" "if" "while" "let\\*?" "prog1" "prog2" =
"progn"
;;                  "catch" "throw" "save-restriction" "save-excursion"
;;                  "save-window-excursion" "save-match-data"
;;                  "unwind-protect" "condition-case" "track-mouse")))
;;   (concat "(" (make-regexp strings t)))
;;
;;      =3D> =
"(\\(c\\(atch\\|ond\\(\\|ition-case\\)\\)\\|if\\|let\\*?\\|prog[12n]\\|sa=
ve-\\(excursion\\|match-data\\|restriction\\|window-excursion\\)\\|t\\(hr=
ow\\|rack-mouse\\)\\|unwind-protect\\|while\\)"
;;
;; To search for the above regexp takes about 70% of the time as for the =
simple
;; (concat "(\\(" (mapconcat 'identity strings "\\|") "\\)") regexp.
;;
;; Obviously, the more the similarity between strings, the faster the =
regexp:
;;
;; (make-regexp '("abort" "abs" "accept" "access" "array" "begin" "body" =
"case"
;;                "constant" "declare" "delay" "delta" "digits" "else" =
"elsif"
;;                "entry" "exception" "exit" "function"  "generic" =
"goto" "if"
;;                "others" "limited" "loop" "mod" "new" "null" "out" =
"subtype"
;;                "package" "pragma" "private" "procedure" "raise" =
"range"
;;                "record" "rem" "renames" "return" "reverse" "select"
;;                "separate" "task" "terminate" "then" "type" "when" =
"while"
;;                "with" "xor"))
;;
;;     =3D> =
"a\\(b\\(ort\\|s\\)\\|cce\\(pt\\|ss\\)\\|rray\\)\\|b\\(egin\\|ody\\)\\|c\=
\(ase\\|onstant\\)\\|d\\(e\\(clare\\|l\\(ay\\|ta\\)\\)\\|igits\\)\\|e\\(l=
s\\(e\\|if\\)\\|ntry\\|x\\(ception\\|it\\)\\)\\|function\\|g\\(eneric\\|o=
to\\)\\|if\\|l\\(imited\\|oop\\)\\|mod\\|n\\(ew\\|ull\\)\\|o\\(thers\\|ut=
\\)\\|p\\(ackage\\|r\\(agma\\|ivate\\|ocedure\\)\\)\\|r\\(a\\(ise\\|nge\\=
)\\|e\\(cord\\|m\\|names\\|turn\\|verse\\)\\)\\|s\\(e\\(lect\\|parate\\)\=
\|ubtype\\)\\|t\\(ask\\|erminate\\|hen\\|ype\\)\\|w\\(h\\(en\\|ile\\)\\|i=
th\\)\\|xor"
;;
;; To search for the above regexp takes less than 60% of the time of the =
simple
;; mapconcat equivalent.
;;
;; But even small regexps may be worth it:
;;
;; (make-regexp '("and" "at" "do" "end" "for" "in" "is" "not" "of" "or" =
"use"))
;;     =3D> "a\\(nd\\|t\\)\\|do\\|end\\|for\\|i[ns]\\|not\\|o[fr]\\|use"
;;
;; as this is 10% faster than the mapconcat equivalent.

;; Installation:
;;=20
;; (autoload 'make-regexp "make-regexp"
;;   "Return a regexp to match a string item in STRINGS.")
;;
;; (autoload 'make-regexps "make-regexp"
;;   "Return a regexp to REGEXPS.")
;;
;; Since these functions were written to produce efficient regexps, not =
regexps
;; efficiently, it is probably not a good idea to in-line too many calls =
in
;; your code, unless you use the following neat trick with =
`eval-when-compile':
;;
;; (defvar definition-regexp
;;   (let ((regexp (eval-when-compile
;;                   (make-regexp '("defun" "defsubst" "defmacro" =
"defalias"
;;                                  "defvar" "defconst" "defadvice") =
t))))
;;     (concat "^(" regexp)))
;;
;; The `byte-compile' code will be as if you had defined the variable =
thus:
;;
;; (defvar definition-regexp
;;   =
"^(\\(def\\(a\\(dvice\\|lias\\)\\|const\\|macro\\|subst\\|un\\|var\\)\\)"=
)

;; Feedback:
;;
;; Originally written for font-lock, from an idea from Stig's hl319.
;; Please don't tell me that it doesn't produce optimal regexps; I know =
that
;; already.  But (ideas or) code to improve things (are) is welcome.  =
Please
;; test your code and tell me the speed up in searching an appropriate =
buffer.
;;
;; Please send me bug reports, bug fixes, and extensions, etc.
;; Simon Marshall <simon@gnu.ai.mit.edu>

;; History:
;;
;; 1.00--1.01:
;; - Made `make-regexp' take `lax' to force top-level parentheses.
;; - Fixed `make-regexps' for MATCH bug and new `font-lock-keywords'.
;; - Added `unfontify' to user timing functions.
;; 1.01--1.02:
;; - Made `make-regexp' `let' a big `max-lisp-eval-depth'.
=0C
;; The basic idea is to find the shortest common non-"" prefix each =
time, and
;; squirrel it out.  If there is no such prefix, we divide the list into =
two so
;; that (at least) one half will have at least a one-character common =
prefix.

;; In addition, we (a) delay the addition of () parenthesis as long as =
possible
;; (until we're sure we need them), and (b) try to squirrel out =
one-character
;; sequences (so we can use [] rather than ()).

(defun make-regexp (strings &optional paren lax)
  "Return a regexp to match a string item in STRINGS.
If optional PAREN non-nil, output regexp parentheses around returned =
regexp.
If optional LAX non-nil, don't output parentheses if it doesn't require =
them.
Merges keywords to avoid backtracking in Emacs' regexp matcher."
  (let* ((max-lisp-eval-depth (* 1024 1024))
	 (strings (let ((l strings))	; Paranoia---make strings unique!
		    (while l (setq l (setcdr l (delete (car l) (cdr l)))))
		    (sort strings 'string-lessp)))
	 (open-paren (if paren "\\(" "")) (close-paren (if paren "\\)" ""))
	 (open-lax (if lax "" open-paren)) (close-lax (if lax "" close-paren))
	 (completion-ignore-case nil))
    (cond
     ;; If there's only one string, just return it.
     ((=3D (length strings) 1)
      (concat open-lax (car strings) close-lax))
     ;; If there's an empty string, pull it out.
     ((string=3D (car strings) "")
      (if (and (=3D (length strings) 2) (=3D (length (nth 1 strings)) =
1))
	  (concat open-lax (nth 1 strings) "?" close-lax)
	(concat open-paren "\\|" (make-regexp (cdr strings)) close-paren)))
     ;; If there are only one-character strings, make a [] list instead.
     ((=3D (length strings) (apply '+ (mapcar 'length strings)))
      (concat open-lax "[" (mapconcat 'identity strings "") "]" =
close-lax))
     (t
      ;; We have a list of strings.  Is there a common prefix?
      (let ((prefix (try-completion "" (mapcar 'list strings))))
	(if (> (length prefix) 0)
	    ;; Common prefix!  Squirrel it out and recurse with the suffixes.
	    (let* ((len (length prefix))
		   (sufs (mapcar '(lambda (str) (substring str len)) strings)))
	      (concat open-paren prefix (make-regexp sufs t t) close-paren))
	  ;; No common prefix.  Is there a one-character sequence?
	  (let ((letters (let ((completion-regexp-list '("^.$")))
			   (all-completions "" (mapcar 'list strings)))))
	    (if (> (length letters) 1)
		;; Do the one-character sequences, then recurse on the rest.
		(let ((rest (let ((completion-regexp-list '("^..+$")))
			      (all-completions "" (mapcar 'list strings)))))
		  (concat open-paren
			  (make-regexp letters) "\\|" (make-regexp rest)
			  close-paren))
	      ;; No one-character sequence, so divide the list into two by
	      ;; dividing into those that start with a particular letter, and
	      ;; those that do not.
	      (let* ((char (substring (car strings) 0 1))
		     (half1 (all-completions char (mapcar 'list strings)))
		     (half2 (nthcdr (length half1) strings)))
		(concat open-paren
			(make-regexp half1) "\\|" (make-regexp half2)
			close-paren))))))))))
=0C
;; This stuff is realy for font-lock...

;; Ahhh, the wonders of lisp...
(defun regexp-span (regexp &optional start)
  "Return the span or depth of REGEXP.
This means the number of \"\\\\(...\\\\)\" pairs in REGEXP, optionally =
from START."
  (let ((match (string-match (regexp-quote "\\(") regexp (or start 0))))
    (if (not match) 0 (1+ (regexp-span regexp (match-end 0))))))

;; The basic idea is to concat the regexps together, keeping count of =
the span
;; of the regexps so that we can get the correct match for hilighting.
(defun make-regexps (&rest regexps)
  "Return a regexp to match REGEXPS
Each item of REGEXPS should be of the form:

 STRING                                 ; A STRING to be used literally.
 (STRING MATCH FACE DATA)               ; Match STRING at depth MATCH =
with FACE
                                        ; and highlight according to =
DATA.
 (STRINGS FACE DATA)                    ; STRINGS is a list of strings =
FACE is
                                        ; to highlight according to =
DATA.

Returns a list of the form:

 (REGEXP (MATCH FACE DATA) ...)

For example:

 (make-regexps \"^(\"
               '((\"defun\" \"defalias\" \"defsubst\" \"defadvice\") =
keyword)
               \"[ \t]*\"
               '(\"\\\\([a-zA-Z-]+\\\\)?\" 1 function-name nil t))

     =3D>

 (\"^(\\\\(def\\\\(a\\\\(dvice\\\\|lias\\\\)\\\\|subst\\\\|un\\\\)\\\\)[ =
	=
]*\\\\([a-zA-Z-]+\\\\)?\"
  (1 keyword) (4 function-name nil t))

Uses `make-regexp' to make efficient regexps."
  (let ((regexp "") (data ()))
    (while regexps
      (cond ((stringp (car regexps))
	     (setq regexp (concat regexp (car regexps))))
	    ((stringp (nth 0 (car regexps)))
	     (setq data (cons (cons (+ (regexp-span regexp)
				       (nth 1 (car regexps)))
				    (nthcdr 2 (car regexps)))
			      data)
		   regexp (concat regexp (nth 0 (car regexps)))))
	    (t
	     (setq data (cons (cons (1+ (regexp-span regexp))
				    (cdr (car regexps)))
			      data)
		   regexp (concat regexp (make-regexp (nth 0 (car regexps))
						      t)))))
      (setq regexps (cdr regexps)))
    (cons regexp (nreverse data))))
=0C
;; Crude-rude timing...

(defsubst time-seconds (&optional time)
  "Return the TIME in seconds, or the current time if not given.
TIME should be the same format as produced by `current-time'."
  (let ((time (or time (current-time))))
    (+ (* (nth 0 time) 65536.0) (nth 1 time) (/ (nth 2 time) =
1000000.0))))

(defsubst time-since (time)
  "Return the time in seconds since TIME.
TIME should be the value of `current-time' or `time-seconds'."
  (- (time-seconds) (if (floatp time) time (time-seconds time))))

(defun time-function (func &rest args)
  "Return the time in seconds taken to execute FUNC with ARGS.
Returned is actually the cons pair (func-value . time)."
  (garbage-collect)
  (let ((start (time-seconds)))
    (cons (apply func args) (time-since start))))

(defun time-regexps (regexps &optional buffer unfontify)
  "Return corresponding list of times to fontify using REGEXPS.
Fontify using BUFFER, if non-nil, and UNFONTIFY first, if non-nil."
  (save-excursion
    (and buffer (set-buffer buffer))
    (let ((beg (point-min)) (end (point-max)))
      (and unfontify (font-lock-unfontify-region beg end))
      (mapcar (function (lambda (regexp)
	       (let ((font-lock-keywords (list regexp)))
		 (cons (cdr (time-function 'font-lock-hack-keywords beg end))
		       regexp))))
	      regexps))))

(defun sort-font-lock-regexps (regexps &optional buffer unfontify)
  "Return sorted times to fontify syntactically and using REGEXPS.
UNFONTIFY first, if non-nil."
  (let ((regexp-time (time-regexps regexps buffer unfontify)))
    (cons (list (apply '+ (mapcar 'car regexp-time)) 'regexps)
          (nreverse (sort regexp-time 'car-less-than-car)))))

(defun time-fontification (&optional buffer unfontify)
  "Return time to fontify syntactically.
UNFONTIFY first, if non-nil."
  (save-excursion
    (and buffer (set-buffer buffer))
    (let ((beg (point-min)) (end (point-max)))
      (and unfontify (font-lock-unfontify-region beg end))
      (cdr (time-function 'font-lock-fontify-region beg end)))))

(defun sort-font-lock-fontification (regexps &optional buffer unfontify)
  "Return sorted times to fontify syntactically and using REGEXPS.
UNFONTIFY first, if non-nil."
  (let ((syntactic-time (time-fontification buffer unfontify))
	(regexp-time (time-regexps regexps buffer)))
    (nreverse
     (sort (append (list (list syntactic-time 'syntactic)
			 (list (apply '+ (mapcar 'car regexp-time)) 'regexps))
		   regexp-time)
	   'car-less-than-car))))

;;; make-regexp.el ends here
--2354_3f66-5d93_7774-4097_6ffe
Content-Type: application/octet-stream; name=dot_emacs
Content-Transfer-Encoding: 7bit
Content-MD5: ecAqgAxRK1HxRHJRqTa02A==
Content-Description: dot_emacs
Content-Disposition: attachment; filename=dot_emacs

;;
;; here are some things you might want to add to your .emacs file
;; 

;
; add some auto-mode things
;
(setq auto-mode-alist 
      (append
       '((".xom$" . omnimark-mode))
       auto-mode-alist)
      )

;
; Omnimark stuff
;
(autoload 'omnimark-mode "omnimark-mode" nil t)

(add-hook 'omnimark-mode-hook 
	  (function 
	   (lambda ()
	     ;; apply all font-lock decorations
	     (setq font-lock-maximum-decoration t)
	     (turn-on-font-lock)
	     (setq abbrev-mode t)
	     ;; indent nested things by 2 spaces
	     (setq omnimark-indent-level 2) 
	     ;; indent the body of Omnimark rules by 2 spaces
	     (setq omnimark-rule-indent 2) 
	     )
	   )
	  )
