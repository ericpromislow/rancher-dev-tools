
(defvar omni-omnimark-executable "/opt/local/bin/omnimark")
(defvar omni-default-program-buffer-name "*OmniMark Program*")
(defvar omni-default-output-buffer-name "*OmniMark Output*")
(defvar omni-default-input-buffer-name "*OmniMark Input*")
(defvar omni-default-log-buffer-name "*OmniMark Log*")
(defvar omni-program-buffer nil)
(defvar omni-output-buffer  nil)
(defvar omni-input-buffer nil)
(put 'omni-program-buffer 'omni-save-name "/tmp/emacs-omni.xom")
(put 'omni-input-buffer   'omni-save-name "/tmp/emacs-omni.in")
(defvar omni-window-configuration nil)
(defvar omni-window-init-done nil)
(defvar omni-program-template
  "cross-translate\n\nfind ")
(defvar omni-setup-has-been-done nil)

(defun killed-buffer-p (buffer)
  "Return t if BUFFER is killed."
  (not (buffer-name buffer)))

(defun omni-exec-omnimark (program-file-name
			   input-file-name
			   output-buffer
			   &optional clear-output-buffer)
  (if clear-output-buffer
      (progn
	(set-buffer output-buffer)
	(kill-region (point-min) (point-max))))
  (call-process omni-omnimark-executable
		input-file-name
		output-buffer
		t			; update display?
		"-brief"
		"-s"
		program-file-name))

(defun omni-setup-buffers ()
  (interactive)
  (mapcar
   (lambda (x)
     (let ((buf (car x))
	   (buf-name (car (cdr x))))
     (if (or (null (eval buf))
	     (killed-buffer-p (eval buf)))
	 (set buf
	      (get-buffer-create buf-name)))))
   '((omni-program-buffer "*OmniMark Program*") 
     (omni-output-buffer  "*OmniMark Output*")
     (omni-input-buffer   "*OmniMark Input*"))))


(defun omni-set-input-buffer ()
  (interactive)
  (setq omni-input-buffer (current-buffer)))

(defun omni-set-output-buffer ()
  (interactive)
  (setq omni-output-buffer (current-buffer)))

(defun omni-set-program-buffer ()
  (interactive)
  (setq omni-program-buffer (current-buffer)))

(defun omni-init-window-configuration ()
  (delete-other-windows)
  (split-window)
  (split-window-horizontally)
  (setq omni-prog-window (selected-window))
  (other-window 1)
  (setq omni-input-window (selected-window))
  (other-window 1)
  (setq omni-output-window (selected-window))
  (setq omni-window-configuration (current-window-configuration))
  (setq omni-window-init-done 't))

(defun omni-setup-windows ()
  (if (null omni-window-init-done)
      (omni-init-window-configuration))
  (set-window-configuration omni-window-configuration)
  (select-window omni-prog-window)
  (switch-to-buffer omni-program-buffer)
  (other-window 1)
  (switch-to-buffer omni-input-buffer)
  (other-window 1)	
  (switch-to-buffer omni-output-buffer)
  (select-window omni-prog-window)
  (if (= 1 (point-max))
      (insert omni-program-template)))

(defun omni-search-replace ()
  (interactive)
  (setq omni-input-buffer (current-buffer))
  (omni-setup-buffers)
  (omni-setup-windows))

(defun omni-save-buffers ()
  (mapcar
   '(lambda (buf) 
      (save-excursion
	(set-buffer (eval buf))
	(let ((org-save-file (buffer-file-name)))
	  (write-region (point-min) (point-max) (get buf 'omni-save-name))
	  (set-visited-file-name org-save-file))))
   '(omni-program-buffer omni-input-buffer)))

(defun omni-call-omnimark ()
  (interactive)
  (omni-setup-buffers)
  (omni-setup-windows)
  (omni-save-buffers)
  (let ((program-file-name 
	 (cond ((get 'omni-program-buffer 'omni-save-name)  
		(get 'omni-program-buffer 'omni-save-name))
	       (t  (error "Couldn't find program to execute"))))
	(input-file-name
	 (cond ((get 'omni-input-buffer 'omni-save-name)
		(get 'omni-input-buffer 'omni-save-name))
	       ('t  (error "Couldn't find output file name.")))))
    (unwind-protect
	(omni-exec-omnimark program-file-name
			    input-file-name
			    omni-output-buffer
			    't)
      (progn
	(delete-file program-file-name)
	(delete-file input-file-name)))))

(global-set-key "\C-coi" 'omni-set-input-buffer)
(global-set-key "\C-cos" 'omni-search-replace)
(global-set-key "\C-cor" 'omni-call-omnimark)
(global-set-key "\C-cot" '(lambda () 
				 (interactive)
				 (insert omni-program-template)))
(global-set-key "\C-coo" 'omni-set-output-buffer)

