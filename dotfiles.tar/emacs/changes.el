; strip-proto
; Copy a block, repeat everything, and remove the prototype definitions

(defun strip-proto ()
  (replace-regexp "([^)]*);" "();"))