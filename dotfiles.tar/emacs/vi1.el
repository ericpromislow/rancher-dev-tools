; vi-hook

(setq vi-mode-hook
      '(lambda () (progn
		    (global-set-key "\e\e" 'vi-mode)
		    (vi-back-to-old-mode)
		    (setq vi-mode-hook nil))))
