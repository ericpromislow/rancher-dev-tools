; First try to get back some of that useful Gosling stuff

(defvar non-gosmacs-binding-alist nil)

(defun set-gosmacs-bindings ()
  "Rebind some keys globally to make GNU Emacs resemble Gosling Emacs.
Use \\[set-gnu-bindings] to restore previous global bindings."
  (interactive)
  (setq non-gosmacs-binding-alist
	(rebind-and-record
	 '(("\C-x\C-e" compile)
	   ("\C-x\C-o" switch-to-buffer)
	   ("\C-xz" shrink-window)
	   ("\C-x!" line-to-top-of-window)
	   ("\C-xn" gosmacs-next-window)
	   ("\C-xp" gosmacs-previous-window)
	   ("\C-z" scroll-one-line-up)
	   ("\e(" backward-paragraph)
	   ("\e)" forward-paragraph)
	   ("\eq" query-replace)
	   ("\er" replace-string)
;	   ("" backward-delete-char-untabify)  ;; aquamacs 24 problem rebinds them to cua-del-region...
;	   ("\C-d" delete-forward-char)
	   ("\ez" scroll-one-line-down)))))

(defun rebind-and-record (bindings)
  "Establish many new global bindings and record the bindings replaced.
Arg is an alist whose elements are (KEY DEFINITION).
Value is a similar alist whose elements describe the same KEYs
but each with the old definition that was replaced,"
  (let (old)
    (while bindings
      (let* ((this (car bindings))
	     (key (car this))
	     (newdef (nth 1 this)))
	(setq old (cons (list key (lookup-key global-map key)) old))
	(global-set-key key newdef))
      (setq bindings (cdr bindings)))
    (nreverse old)))

(defun set-gnu-bindings ()
  "Restore the global bindings that were changed by \\[set-gosmacs-bindings]."
  (interactive)
  (rebind-and-record non-gosmacs-binding-alist))

(defun gosmacs-previous-window ()
  "Select the window above or to the left of the window now selected.
From the window at the upper left corner, select the one at the lower right."
  (interactive)
  (select-window (previous-window)))

(defun gosmacs-next-window ()
  "Select the window below or to the right of the window now selected.
From the window at the lower right corner, select the one at the upper left."
  (interactive)
  (select-window (next-window)))

(defun scroll-one-line-up (&optional arg)
  "Scroll the selected window up (forward in the text) one line (or N lines)."
  (interactive "p")
  (scroll-up (or arg 1)))

(defun scroll-one-line-down (&optional arg)
  "Scroll the selected window down (backward in the text) one line (or N)."
  (interactive "p")
  (scroll-down (or arg 1)))

(defun line-to-top-of-window ()
  "Scroll the selected window up so that the current line is at the top."
  (interactive)
  (recenter 0))
