# .bashrc

# User specific aliases and functions
#
# Obsolete: Use .profile instead!!!

# Source global definitions

# echo 'source .bashrc...'

if [ -f /etc/bashrc ]; then
	. /etc/bashrc
fi

if [ -f ~/.bash_aliases ]; then
    . ~/.bash_aliases
fi

alias ll='ls -alF'
alias la='ls -A'


# export PROMPT_COMMAND='echo -ne "\033]0;${USER}@${HOSTNAME}: ${PWD}\007"'

#export PS1='\W $ '

# echo "QQQ: PATH: $PATH"
# echo "QQQ: GOROOT: $GOROOT"

if [ -z $(echo $PATH | grep -qs '/opt/homebrew/bin') ] ; then
  export PATH=$PATH:/opt/homebrew/bin
fi

if [[ -z "${GOROOT:-}" || $GOROOT == "/libexec" ]] ; then
    # export GOROOT=$(find /opt/homebrew/Cellar/go -type d -depth 1 | tac | head -1)/libexec
    export GOROOT=/opt/homebrew/Cellar/go@1.24/1.24.7/libexec
    go env -w GOTOOLCHAIN=go1.24.7+auto
    echo export GOROOT=$GOROOT   # /opt/homebrew/Cellar/go/1.23.0
fi
export GOPATH=$HOME/go
export PATH=$HOME/bin:$GOROOT/bin:$PATH:$GOPATH/bin

export GOROOT=/opt/homebrew/Cellar/go@1.24/1.24.7/libexec && go env -w GOTOOLCHAIN=go1.24.7+auto && go version

### Added by the Heroku Toolbelt
### export PATH="/usr/local/heroku/bin:$PATH"

echo before source ~/.git-completion.bash
source ~/.git-completion.bash
echo after source ~/.git-completion.bash

echo before source ~/.git-prompt.bash
source ~/bin/.git-prompt.sh
echo after source ~/.git-prompt.bash

# If this is an xterm set the title to user@host:dir
case "$TERM" in
xterm*|rxvt*)
    #PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \W\a\]$PS1"
    PS1='\h:\W$(__git_ps1 "(%.12s)") \$ '
    ;;
*)
    ;;
esac

#CW which fasd > /dev/null || export PATH=/usr/local/bin:$PATH
#CW eval "$(fasd --init auto)"

# export CF_PLUGIN_HOME=${HOME}

alias diff-highlight=/usr/local/share/git-core/contrib/diff-highlight/diff-highlight
alias dh=diff-highlight

[ -f ~/.fzf.bash ] && source ~/.fzf.bash

# echo 'about to check L'
# set -x
# alias L 2>/dev/null || source ~/.profile

#source /usr/local/Cellar/nvm/0.38.0/nvm.sh
export NVM_DIR="$HOME/.nvm"

[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && . "$NVM_DIR/bash_completion"  

export LIMA_HOME="$HOME/Library/Application Support/rancher-desktop/lima"
export PATH="$PATH":$HOME/workspace/rancher/desktop/resources/darwin/lima/bin

eval $(ssh-agent -s)
eval "$(/opt/homebrew/bin/brew shellenv)"

C=cattle-system

alias goland=/Applications/GoLand.app/Contents/MacOS/goland

# Last line of before file
. "$HOME/.cargo/env"

### MANAGED BY RANCHER DESKTOP START (DO NOT EDIT)
export PATH="/Users/ericp/.rd/bin:$PATH"
### MANAGED BY RANCHER DESKTOP END (DO NOT EDIT)
