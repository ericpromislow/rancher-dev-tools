# .profile

# User specific aliases and functions

# Source global definitions
#if [ -f /etc/bashrc ]; then
#	. /etc/bashrc
#fi

alias l="ls -CFA"
alias L="ls -l"
alias hi="history | tail -100"
# Setting LESS ruins colors
# export LESS="-EiXm"
alias more="less"
alias rm=mvtrash

# if [ -f ~/lab/ddirs/ddirs.sh ] ; then
#   . ~/lab/ddirs/ddirs.sh
# else
# alias d1='d1=`pwd`'
# alias cd1='cd "$d1"'
# alias d2='d2=`pwd`'
# alias cd2='cd "$d2"'
# alias d3='d3=`pwd`'
# alias cd3='cd "$d3"'
# alias d4='d4=`pwd`'
# alias cd4='cd "$d4"'
# alias d='echo $d1;echo $d2; echo $d3; echo $d4'
# d1=/home/eric/gather
# # d2=/home/httpd/html
# # d3=/home/httpd/cgi-bin
# d1=$HOME/lab/web/hi5fit
# d2=$HOME/lab/web/cars01
# fi

# alias s=stackato

alias vbm=VBoxManage
# alias gbs="git status | grep branch"
# alias gsu="git status | sed /Untracked/q"

# export CDPATH=".:~/gather:/home/httpd"

export IGNOREEOF=2
# export PROMPT_COMMAND='echo -ne "\033]0;${USER}@${HOSTNAME}: ${PWD}\007"'

export PATH=~/bin:/usr/local/bin:/usr/local/sbin:$PATH

# export PS1='\W $ '

# export P4PORT=1666
# export P4HOST=carltonx
export VISUAL=vim
export EDITOR=vim

export PERL5LIB=$HOME/lib/perl/5.8.6
#
# Your previous .profile  (if any) is saved as .profile.mpsaved
# Setting the path for MacPorts.

# echo $PATH | grep -q 'Python.framework/Versions/3' || export PATH="$PATH:/Library/Frameworks/Python.framework/Versions/3.1/bin"
# echo $PATH | grep -q 'ruby-1.9.2' || export PATH="$HOME/opt/ruby-1.9.2-p0/bin:$PATH"

##
# Your previous /Users/Eric/.profile file was backed up as /Users/Eric/.profile.macports-saved_2009-06-19_at_22:36:14
##

# MacPorts Installer addition on 2009-06-19_at_22:36:14: adding an appropriate MANPATH variable for use with MacPorts.
# export MANPATH=/opt/local/share/man:$MANPATH
# Finished adapting your MANPATH environment variable for use with MacPorts.

# d3=/Users/Eric/work/svn/komodo
# d4=/Users/Eric/work/svn/openkomodo
# d4=/Users/Eric/work/svn/branches/komodo-scintilla-321/src
# export PATH=/usr/local/ActivePerl-5.8/bin:$PATH
# export R_LIBS=/Library/Frameworks/R.framework/Resources/library

# PEP 370 PATH added by PyPM on 2011-02-24 10:24:46.921929
#### export PATH=/Users/Eric/Library/Python/2.7/bin:$PATH
# which -s pgbench || export PATH=/Library/PostgreSQL/8.4/bin:$PATH
##
# Your previous /Users/Eric/.profile file was backed up as /Users/Eric/.profile.macports-saved_2012-10-18_at_21:59:03
##

# MacPorts Installer addition on 2012-10-18_at_21:59:03: adding an appropriate PATH variable for use with MacPorts.
# export PATH=/opt/local/bin:$HOME/Library/Python/2.7/bin:$PATH:$HOME/bin
# Finished adapting your PATH environment variable for use with MacPorts.


# Added by Canopy installer on 2015-09-27
# VIRTUAL_ENV_DISABLE_PROMPT can be set to '' to make bashprompt show that Canopy is active, otherwise 1
# VIRTUAL_ENV_DISABLE_PROMPT=1 source '/Users/Eric/Library/Enthought/Canopy_64bit/User/bin/activate'

# eval "$(rbenv init -)"
#@
export VISUAL=/usr/bin/vim
export EDITOR=$VISUAL

# export POSTGRES_CONNECTION_PREFIX=postgres://postgres:postgres@localhost:5432
# export MYSQL_CONNECTION_PREFIX=mysql2://root:password@localhost:3306

# Raise max # of open files
case `ulimit -n` in
    256) ulimit -n 1024 ;;
esac

set -o noclobber

# export PATH=$PATH:$HOME/workspace/relint-workstation/scripts

# export PATH="/usr/local/opt/openssl@1.1/bin:$PATH"
# export LDFLAGS="-L/usr/local/opt/openssl@1.1/lib"
# export CPPFLAGS="-I/usr/local/opt/openssl@1.1/include"
# export PKG_CONFIG_PATH="/usr/local/opt/openssl@1.1/lib/pkgconfig"

if alias -p | grep -sq 'alias k=' ; then
  test -x $HOME/bin/k && unalias k
fi


set +e
# unalias vi
# unalias vim
export GIT_EDITOR=vim
export PATH=$PATH:/usr/local/kubebuilder/bin
# 
# Last line of .profile 
source "$HOME/.cargo/env"
