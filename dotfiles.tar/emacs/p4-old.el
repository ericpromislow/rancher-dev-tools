(defvar p4-executable "c:/apps/Perforce/p4.exe")
(defvar p4-output-buffer-name "*P4 Output*")
(defvar p4-output-buffer  nil)
(setenv "P4PORT" "perforce:1667")
(setenv "P4CLIENT" "ericp")
(setenv "P4ROOT" "c:")

(defun p4-exec-p4 (output-buffer
		   args
		   &optional clear-output-buffer)
  (if clear-output-buffer
      (progn
	(set-buffer output-buffer)
	(kill-region (point-min) (point-max))))
  (apply 'call-process 
	 (append 
	  (list p4-executable
		"nul"
		output-buffer
		nil)		; update display?
	  args)))

(defun p4-buffer-action (cmd do-revert show-output)
  (save-excursion
    (if (not (stringp cmd))
	(error "p4-buffer-action: Command not a string."))
    (save-excursion
      (p4-exec-p4 (get-buffer-create p4-output-buffer-name)
		  (list cmd (buffer-file-name)) 't))
    (if do-revert (revert-buffer 't 't))
    (if show-output
	(progn
	  (delete-other-windows)
	  (split-window (get-buffer-window (current-buffer)) 6)
	  (switch-to-buffer (get-buffer p4-output-buffer-name))))))

(defun p4-edit (show-output)
  (interactive "P")
  (p4-buffer-action "edit" 't show-output))

(defun p4-revert (show-output)
  (interactive "P")
  (p4-buffer-action "revert" 't show-output))

(defun p4-diff ()
  (interactive)
  (p4-buffer-action "diff" 'nil 't))
