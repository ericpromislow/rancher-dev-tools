alias more="less -EiXm"
alias moire="less -EiXm"
alias moer="less -EiXm"

alias gingko=ginkgo

# The only git aliases I use
alias glg='git lg | \more'
alias gst='git status'

alias ggn="git grep -n"

# rancher desktop work

alias minikube-start="minikube start -b k3s -p rancher-desktop --driver hyperkit --container-runtime containerd"

alias mk="MINIKUBE_HOME=$HOME'/Library/Application Support/rancher-desktop' minikube -p rancher-desktop"
